# Security Policy

We take security very seriously in mangos, since you may be using it in
Internet-facing applications.

## Reporting a Vulnerability

To report a vulnerability, please contact us on our discord.
You may also send an email to garrett@damore.org, or info@staysail.tech.

We will keep the reporter updated on any status updates on a regular basis,
and will respond within two business days for any reported security issue.
